(function ($) {
 "use strict";
 
	$(".dial").knob();

 
})(jQuery); 